# Pintor-Proyecto
EL proyecto de semestre de la materia Lenguajes y Automatas
